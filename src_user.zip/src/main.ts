
// import { bootstrapApplication } from '@angular/platform-browser';
// import { appConfig } from './app/app.config';
// import { App } from './app/app';
// import { provideHttpClient } from '@angular/common/http'; // ✅ Required
// import { provideStore } from '@ngrx/store';
// import { provideEffects } from '@ngrx/effects';
// import { provideRouter } from '@angular/router';
// import { userReducer } from './app/user.reducer';
// import { appRoutes } from './app/app.routes';
// import { UserEffects } from './app/user.effects';
// //bootstrapApplication(App, appConfig).catch((err) => console.error(err));

// bootstrapApplication(App, {
//   providers: [
//     provideHttpClient(), // ✅ Registers HttpClient globally
//     provideRouter(appRoutes),
//     // provideStore({ user: userReducer }),
//     // provideEffects([UserEffects])
//   ]
// });



import { bootstrapApplication } from '@angular/platform-browser';
import { App } from './app/app';
import { importProvidersFrom } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { appRoutes } from './app/app.routes';
import { userFeatureKey, userReducer } from './app/user.reducer';

bootstrapApplication(App, {
  providers: [
     provideHttpClient(), // ✅ Registers HttpClient globally
    provideRouter(appRoutes),
    importProvidersFrom(
     StoreModule.forRoot({}, {}),
      StoreModule.forFeature(userFeatureKey, userReducer),
      EffectsModule.forRoot([])
    ),
    // other providers
  ]
}).catch(err => console.error(err));
