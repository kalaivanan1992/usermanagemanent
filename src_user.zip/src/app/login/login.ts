// login.component.ts
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { Dashboard } from '../dashboard/dashboard';

@Component({
  selector: 'app-login',
  templateUrl: './login.html',
  standalone:true,
  providers: [Dashboard],
  imports:[ReactiveFormsModule,FormsModule,CommonModule],
  styleUrl:'./login.scss'
})
export class LoginComponent {
  loginForm: FormGroup;
  errorMessage: string;

  constructor(private fb: FormBuilder, private router: Router, private loginService: AuthService) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }
 get formStateClass(): string {
    if (this.loginForm.pristine) return 'bg-neutral';
    if (this.loginForm.valid) return 'bg-success';
    return 'bg-error';
  }
  onLogin(): void {
    const { username, password } = this.loginForm.value;
   
 this.loginService.login(username!, password!).subscribe({
    
        next: (isValid) => {
           console.log(isValid)
        if (isValid) {
          this.router.navigate(['/dashboard']);
        } else {
          this.errorMessage = 'Invalid credentials';
      
        }
      },
      error: () => {
        this.errorMessage = 'Server error';
      }
    });

    // Mock login logic
  
  }
}
