// user.reducer.ts
import { createReducer, on } from '@ngrx/store';
import * as UserActions from './user.actions';
import { User } from './user.model';
export const userFeatureKey = 'user';

export interface UserState {
  users: User[];
  loading: boolean;
  error: any;
}

// export const initialState: UserState = {
//   users: [],
//   loading: false,
//   error: null
// };

export const initialUserState: UserState = {
  users: [],
  loading: false,
  error: null
};

export const userReducer = createReducer(
  initialUserState,
  on(UserActions.loadUsers, state => ({ ...state, loading: true })),
  on(UserActions.loadUsersSuccess, (state, { users }) => ({ ...state, loading: false, users })),
  on(UserActions.loadUsersFailure, (state, { error }) => ({ ...state, loading: false, error })),

  on(UserActions.addUser, state => ({ ...state, loading: true })),
  on(UserActions.addUserSuccess, (state, { user }) => ({ ...state, loading: false, users: [...state.users, user] })),
  on(UserActions.addUserFailure, (state, { error }) => ({ ...state, loading: false, error })),

  on(UserActions.updateUser, state => ({ ...state, loading: true })),
  on(UserActions.updateUserSuccess, (state, { user }) => ({
    ...state,
    loading: false,
    users: state.users.map(u => u.id === user.id ? user : u)
  })),
  on(UserActions.updateUserFailure, (state, { error }) => ({ ...state, loading: false, error })),

  on(UserActions.deleteUser, state => ({ ...state, loading: true })),
  on(UserActions.deleteUserSuccess, (state, { id }) => ({
    ...state,
    loading: false,
    users: state.users.filter(u => u.id !== id)
  })),
  on(UserActions.deleteUserFailure, (state, { error }) => ({ ...state, loading: false, error }))
);
