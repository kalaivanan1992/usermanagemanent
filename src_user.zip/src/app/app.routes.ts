import { Route, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login';
import { Injectable, NgModule } from '@angular/core';
import { Dashboard } from './dashboard/dashboard';

export const appRoutes: Route[] = [ { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: Dashboard },
  { path: '', redirectTo: 'login', pathMatch: 'full' }];

  @NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule],
})
@Injectable({ providedIn: 'root' })
export class AppRoutingModule {}