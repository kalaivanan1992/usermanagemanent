import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { User } from '../user.model';
import * as UserActions from '../user.actions';
import { selectAllUsers } from '../user.selectors';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.scss']
})
export class Dashboard {
  users$: Observable<User[]>;
  selectedUser: User | null = null;
  name = '';
  email = '';

  constructor(private store: Store) {
  //  this.users$.subscribe(users => console.log('users$', users));
    this.users$ = this.store.select(selectAllUsers);
    console.log(this.store.select(selectAllUsers))
    this.store.dispatch(UserActions.loadUsers());
  }

  submit() {
    const user: User = { id: this.selectedUser?.id ?? 0, username: this.name, email: this.email };
    if (this.selectedUser) {
      this.store.dispatch(UserActions.updateUser({ user }));
    } else {
      this.store.dispatch(UserActions.addUser({ user }));
    }
    this.reset();
  }

  edit(user: User) {
    this.selectedUser = user;
    this.name = user.username;
    this.email = user.email;
  }

  delete(id: number) {
    this.store.dispatch(UserActions.deleteUser({ id }));
  }

  reset() {
    this.selectedUser = null;
    this.name = '';
    this.email = '';
  }
}
