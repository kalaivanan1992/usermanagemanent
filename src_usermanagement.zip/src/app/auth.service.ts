// auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {
  isLoggedIn() {
    throw new Error('Method not implemented.');
  }
  
  constructor(private http: HttpClient) {}

  login(username: string, password: string): Observable<boolean> {
    return this.http.get<any[]>(`http://localhost:3000/User`).pipe(
      map(users => {
        return users.some(user => user.username === username && user.password === password);
      })
    );
  }
}
