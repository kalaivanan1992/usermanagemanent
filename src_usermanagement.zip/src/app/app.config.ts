// app.config.ts
// import { provideRouter } from '@angular/router';
// import { appRoutes } from './app.routes';

// export const appConfig = [
//   provideRouter(appRoutes) // ✅ Now it's an array
// ];

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { userReducer } from './user.reducer';
import { UserEffects } from './user.effects';
import { NgModule } from '@angular/core';

@NgModule({
  imports: [
    StoreModule.forRoot({ user: userReducer }),
    EffectsModule.forRoot([UserEffects]),
    // … other imports
  ],
  // …
})
export class appConfig {}

