// user.selectors.ts
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { userFeatureKey, UserState } from './user.reducer';

//export const selectUserState = createFeatureSelector<UserState>('user');
export const selectUserState = createFeatureSelector<UserState>(userFeatureKey);

// export const selectAllUsers = createSelector(
//   selectUserState,
//   (state: UserState) => state.users
// );
//console.log('userssss',selectAllUsers)

export const selectAllUsers = createSelector(
  selectUserState,
  state => state.users
);

export const selectLoading = createSelector(
  selectUserState,
  (state: UserState) => state.loading
);

export const selectError = createSelector(
  selectUserState,
  (state: UserState) => state.error
);
