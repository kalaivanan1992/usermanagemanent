import { UserState } from './user.reducer';

export interface AppState {
  auth: UserState;
}
