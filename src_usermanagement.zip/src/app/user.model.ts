export interface User {
  id: number;
  username: string;
  email: string;
  // any other fields you want
}