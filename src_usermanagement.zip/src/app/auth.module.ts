import { EffectsModule } from '@ngrx/effects';
import { UserEffects } from './user.effects';
import { NgModule } from '@angular/core';

@NgModule({
  imports: [
    EffectsModule.forRoot([UserEffects])   ]
})
export class AuthModule{}
